from django.contrib import admin
from mystranger_app.models import WaitingArea , GroupConnect

# Register your models here.
admin.site.register(WaitingArea)
admin.site.register(GroupConnect)