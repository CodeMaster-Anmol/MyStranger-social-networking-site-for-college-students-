from django.apps import AppConfig


class MystrangerAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'mystranger_app'
